package tv.reltv.storyboard;

import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(15,17,22));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(15,17,22));
    WebView web = new WebView(this);
    web.setBackgroundColor(android.graphics.Color.rgb(15,17,22));
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  private class AndroidBridge {
    @JavascriptInterface
    public void saveFile(String fileName, String content, String mimeType) {
      try {
        String safeName = fileName == null ? "ReL-TV-Storyboard-export.txt" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
        String type = mimeType == null ? "text/plain" : mimeType;
        OutputStream output;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          ContentValues values = new ContentValues();
          values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
          values.put(MediaStore.MediaColumns.MIME_TYPE, type);
          values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ReL TV Storyboard Studio");
          Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
          if (uri == null) throw new Exception("Tidak dapat membuat fail dalam folder Downloads");
          output = getContentResolver().openOutputStream(uri);
          if (output == null) throw new Exception("Tidak dapat membuka fail untuk ditulis");
        } else {
          File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
          if (dir == null) throw new Exception("Folder simpanan tidak tersedia");
          if (!dir.exists() && !dir.mkdirs()) throw new Exception("Tidak dapat membuat folder simpanan");
          output = new FileOutputStream(new File(dir, safeName));
        }
        output.write((content == null ? "" : content).getBytes("UTF-8"));
        output.flush();
        output.close();
        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Fail disimpan: Downloads/ReL TV Storyboard Studio", Toast.LENGTH_LONG).show());
      } catch (Exception e) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Eksport gagal: " + e.getMessage(), Toast.LENGTH_LONG).show());
      }
    }
  }

  @Override public void onBackPressed() { super.onBackPressed(); }
}
