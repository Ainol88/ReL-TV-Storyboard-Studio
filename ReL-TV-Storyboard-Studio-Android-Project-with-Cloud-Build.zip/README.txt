ReL TV STORYBOARD STUDIO — Android project
Versi 1.0.0

Fitur prototipe:
- Dashboard sinematik dark/gold
- Buat, buka, edit, dan hapus proyek film
- Master Sheet karakter, lokasi, props, dan wardrobe
- Scene Builder: judul, durasi, aksi, dialog, SFX, musik/narator
- Prompt Generator untuk foto/video
- Simpan otomatis pada perangkat melalui penyimpanan browser lokal WebView
- Export proyek ke JSON dan salin prompt

CARA MEMBUAT APK:
1. Buka folder proyek ini menggunakan Android Studio (versi baru).
2. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh Android Gradle Plugin/SDK yang diminta.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

Catatan jujur: paket ini adalah proyek sumber Android Studio, bukan file APK yang sudah dikompilasi. Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle sehingga APK tidak dapat dikompilasi dan diuji di sini. Data proyek disimpan lokal di aplikasi; hapus data aplikasi dapat menghapus data tersebut.

BUILD ONLINE DENGAN GITHUB ACTIONS (boleh melalui browser HP):
1. Buat repository baru di GitHub.
2. Upload semua isi folder projek ini ke repository (bukan ZIP-nya), termasuk folder tersembunyi .github/workflows/android-build.yml.
3. Buka tab Actions dan pilih workflow "Build ReL TV Storyboard Studio APK", lalu tekan Run workflow.
4. Setelah hijau/sukses, buka hasil run tersebut dan unduh artifact "ReL-TV-Storyboard-Studio-APK". Ekstrak artifact untuk mendapatkan app-debug.apk.
Catatan: workflow ini disediakan sebagai konfigurasi build; prosesnya tetap perlu dijalankan dan diverifikasi di GitHub.
