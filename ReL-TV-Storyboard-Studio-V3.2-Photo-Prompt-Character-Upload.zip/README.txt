ReL TV Storyboard Studio V3.2 — Photo Prompt + Character Face Upload

FITUR V3.2
1. Prompt Generator kini mempunyai pilihan Prompt Video dan Prompt Foto.
2. Character Studio menyediakan menu pilih foto dari galeri telefon, pratonton foto, dan pilihan hapus foto.
3. Foto karakter dikecilkan secara automatik untuk mengurangkan penggunaan storan dan disimpan bersama data karakter pada peranti.
4. Prompt video sedia ada dan eksport JSON/TXT dikekalkan.

CARA MEMBINA APK MELALUI GITHUB ACTIONS
1. Ekstrak ZIP ini pada telefon/komputer jika mahu memeriksa kandungan.
2. Muat naik kandungan projek ke repository GitHub, termasuk folder app, gradle.properties, build.gradle dan settings.gradle.
3. Buka tab Actions dan jalankan workflow “Build ReL TV Storyboard Studio APK”.
4. Apabila workflow berjaya, buka hasil Artifacts dan muat turun ReL-TV-Storyboard-Studio-APK.
5. Ekstrak fail artifact jika berbentuk ZIP, kemudian pasang app-debug.apk pada telefon Android.

CATATAN
- Uji pemilihan foto melalui Character Studio pada telefon sebenar kerana pemilih fail bergantung pada Android WebView.
- Data disimpan secara lokal pada perangkat. Hapus data aplikasi boleh menghapus projek dan foto yang disimpan.
- Foto karakter yang disimpan ikut disertakan dalam backup JSON; saiz backup mungkin bertambah.
- Kod sumber menyediakan workflow GitHub Actions untuk build APK.
